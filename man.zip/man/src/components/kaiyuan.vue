<template>
  <h4>关于前端</h4>


  <h6>我们现在的前端所处的是工程化，工程化就意味着，工作的分配更细致</h6>
  <h6>但是这种细致，要不得不承认随着项目的复杂度，工程化会越来越臃肿</h6>
  <h6>那么就要说到设计模式了，我们用的vue是一种声明式+命令式</h6>
  <h2>我们常用的jquery</h2>
  <h6>是一个命令式框架</h6>
  <h6>是一个命令式框架，我们要清楚命令式框架是性能最好的框架，因为框架永远达不到原生的性能</h6>
  <h6>只能无限的接近原生性能</h6>
  <h6>我想做一名优秀的程序员</h6>

  <img :src="head_img" alt="">
</template>

<script setup>

import axios from "axios";
import {ref} from "vue";
let head_img=ref('1')
axios.get('https://cnodejs.org/api/v1/topic_collect/alsotang').then(res=>{
  // console.log(res.data.data[0].author.avatar_url)
   head_img.value=res.data.data[0].author.avatar_url
  console.log(head_img)
})
</script>

<style scoped>

</style>