<template>
  <el-descriptions
      title="这是我的个人信息"
      direction="vertical"
      :column="4"
      :size="size"
      border
  >
    <el-descriptions-item label="Username">夏宇航</el-descriptions-item>
    <el-descriptions-item label="Telephone">18888888888888</el-descriptions-item>
    <el-descriptions-item label="Place" :span="2">地球</el-descriptions-item>
    <el-descriptions-item label="Remarks">
      <el-tag size="small">School</el-tag>
    </el-descriptions-item>
    <el-descriptions-item label="Address"
    >如果有对开源感兴趣可以联系我,我联系方式是:647578885
    </el-descriptions-item>

  </el-descriptions>

</template>

<script>
export default {
  name: "user"
}
</script>

<style scoped>

</style>