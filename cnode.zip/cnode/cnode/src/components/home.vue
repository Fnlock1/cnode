<template>
  <el-carousel :interval="4000" type="card" height="200px">
    <el-carousel-item v-for="item in 6" :key="item">
      <h3>{{ item }}</h3>
    </el-carousel-item>
  </el-carousel>



  <div class="common-layout">
    <el-container>
      <el-main>

        <el-tabs :tab-position="tab_right" style="" class="demo-tabs">
          <el-tab-pane label="User">
            <user></user>
          </el-tab-pane>
          <el-tab-pane label="Config">Config</el-tab-pane>
          <el-tab-pane label="Role">Role</el-tab-pane>
          <el-tab-pane label="Task">Task</el-tab-pane>
        </el-tabs>

      </el-main>
      <el-footer>



      </el-footer>
    </el-container>
  </div>
</template>



<script setup>

import {ref} from "vue";
import User from "./user.vue";
const tab_right =ref('right')

</script>

<style  scoped>

.el-carousel__item h3 {
  color: #475669;
  font-size: 14px;
  opacity: 0.75;
  line-height: 200px;
  margin: 0;
  text-align: center;
}

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n + 1) {
  background-color: #d3dce6;
}

</style>