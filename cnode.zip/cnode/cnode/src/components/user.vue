<template>

  <div class="head_flex">
    <el-avatar :src="head_img" />
    <h5>{{head_name}}</h5>
  </div>

  <h6 style="margin-top: 2rem">注册时间&nbsp;&nbsp;&nbsp;&nbsp;:{{create_time}}</h6>

  <h3 style="margin-top:3rem;font-style: italic">文章</h3>

  <div v-for="(item,index) in head_title[0]" >


      <el-avatar :src="head_img" />
      <h5>{{head_name}}</h5>

  </div>


</template>

<script setup>

import axios from "axios";
import {reactive, ref} from "vue";
const head_img = ref('')
const head_name=ref('')
const create_time=ref('')
let head_title=reactive([])
axios.get('https://cnodejs.org/api/v1/user/alsotang').then(res=>{
  // console.log(res.data.data.recent_topics);
  head_img.value=res.data.data.avatar_url
  head_name.value=res.data.data.loginname
  create_time.value=res.data.data.create_at
  head_title.push(res.data.data.recent_topics)
  console.log(head_title)
})

</script>

<style scoped>
.head_flex{
  display: flex;
  width:8rem;
  justify-content:space-between
}

</style>