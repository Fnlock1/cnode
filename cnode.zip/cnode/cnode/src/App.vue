<script setup>
  import home from './components/home.vue'
</script>

<template>
  <home></home>
</template>

<style>
*{
  padding: 0px;
  margin: 0px;
}
</style>
